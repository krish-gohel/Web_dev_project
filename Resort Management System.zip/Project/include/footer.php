<footer>
<center>
   <ul>
      <li><a href="index.php"> Home </a></li>
      <li><a href="Room.php"> Rooms </a></li>
      <li><a href="Review.php"> Review </a></li>
      <li><a href="Contact.php">Contact Us</a></li>
   </ul>
   <p>
      PARADISE ROYALE
   </p>
</center>
</footer>
</body>
</html>
