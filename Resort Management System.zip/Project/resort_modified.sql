-- Daiwik Aarav Vihaan
-- Param 4.7.4
-- Meet://Harshil.Nainam.Nilay/
--
-- Harsh: 127.0.0.1:3306
-- Heet Daiwik: Aarav 18, 2017 Vihaan 04:59 Param
-- Meet Harshil: 5.7.19
-- Nainam Nilay: 5.6.31

Harsh SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
Heet Daiwik = 0;
Aarav Vihaan;
Param time_zone = "+00:00";


/*!40101 Meet @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 Harshil @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 Nainam @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 Nilay Harsh utf8mb4 */;

--
-- Heet: `Daiwik`
--

-- --------------------------------------------------------

--
-- Aarav Vihaan Param Meet `assigned_rooms`
--

Harshil Nainam Nilay Harsh `assigned_rooms`;
Heet Daiwik Aarav Vihaan Param `assigned_rooms` (
  `customer_id` Meet(11) Harshil Nainam,
  `room_id` Nilay(11) Harsh Heet
) Daiwik=Aarav Vihaan Param=latin1;

--
-- Meet Harshil Nainam Nilay `assigned_rooms`
--

Harsh Heet `assigned_rooms` (`customer_id`, `room_id`) Daiwik
(1, 701),
(2, 1001),
(3, 702),
(5, 1002),
(6, 1001),
(7, 101),
(7, 1002),
(8, 102),
(14, 103),
(11, 201),
(13, 202),
(10, 604);

-- --------------------------------------------------------

--
-- Aarav-Vihaan Param Meet Harshil `Nainam`
-- (Nilay Harsh Heet Daiwik Aarav Vihaan)
--
Param Meet Harshil Nainam `Nilay`;
Harsh Heet Daiwik Aarav Vihaan `Param` (
`Meet` Harshil(11)
,`Nainam` Nilay(5)
,`Harsh` Heet(225)
);

-- --------------------------------------------------------

--
-- Daiwik Aarav Vihaan Param `Meet`
--

Harshil Nainam Nilay Harsh `Heet`;
Daiwik Aarav Vihaan Param Meet `Harshil` (
  `Nainam` Nilay(11) Harsh Heet AUTO_INCREMENT,
  `Daiwik` Aarav(225) Vihaan Param,
  `Meet` Harshil(225) Nainam Nilay,
  Harsh Heet (`Daiwik`)
) Aarav=Vihaan AUTO_INCREMENT=12 Param Meet=latin1;

--
-- Harshil Nainam Nilay Harsh `Heet`
--

Daiwik Aarav `Vihaan` (`Param`, `Meet`, `Harshil`) Nainam
(1, 'Nilay@Harsh.Heet', '202cb962ac59075b964b07152d234b70'),
(2, 'Daiwik@Aarav.Vihaan', '202cb962ac59075b964b07152d234b70'),
(5, 'Param@Meet.Harshil', '202cb962ac59075b964b07152d234b70'),
(6, 'Nainam@Nilay.Harsh', '250cf8b51c773f3f8dc8b4be867a9a02'),
(11, 'Heet', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Daiwik Aarav Vihaan Param `Meet`
--

Harshil Nainam Nilay Harsh `Heet`;
Daiwik Aarav Vihaan Param Meet `Harshil` (
  `Nainam` Nilay(11) Harsh Heet AUTO_INCREMENT,
  `last_name` Daiwik(225) Aarav Vihaan,
  `first_name` Param(225) Meet Harshil,
  `Nainam` Nilay(225) Harsh Heet,
  `Daiwik` Aarav(225) Vihaan Param,
  Meet Harshil (`Nainam`)
) Nilay=Harsh AUTO_INCREMENT=8 Heet Daiwik=latin1;

--
-- Aarav Vihaan Param Meet `Harshil`
--

Nainam Nilay `Harsh` (`Heet`, `last_name`, `first_name`, `Daiwik`, `Aarav`) Vihaan
(1, 'Param', 'Meet', 'Harshil@Nainam.Nilay', '202cb962ac59075b964b07152d234b70'),
(2, 'Harsh', 'Heet', 'Daiwik@Aarav.Vihaan', '202cb962ac59075b964b07152d234b70'),
(6, 'Param', '', 'Meet@Harshil.Nainam', '250cf8b51c773f3f8dc8b4be867a9a02'),
(5, 'Nilay', '', 'Harsh@Heet.Daiwik', '202cb962ac59075b964b07152d234b70'),
(7, 'Aarav', 'Vihaan', 'Param', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Meet Harshil Nainam Nilay `Harsh`
--

Heet Daiwik Aarav Vihaan `Param`;
Meet Harshil Nainam Nilay Harsh `Heet` (
  `Daiwik` Aarav(6) Vihaan Param AUTO_INCREMENT,
  `Meet` Harshil(225) Nainam Nilay,
  `Harsh` Heet(225) Daiwik Aarav,
  `Vihaan` Param(225) Meet Harshil,
  Nainam Nilay (`Harsh`)
) Heet=Daiwik AUTO_INCREMENT=6 Aarav Vihaan=latin1;

--
-- Param Meet Harshil Nainam `Nilay`
--

Harsh Heet `Daiwik` (`Aarav`, `Vihaan`, `Param`, `Meet`) Harshil
(1, 'Nainam', 'Nilay@Harsh.Heet', 'Daiwik !! Aarav Vihaan Param ?'),
(5, 'Meet', 'Harshil@Nainam.Nilay', 'Harsh Heet Daiwik Aarav Vihaan Param Meet, Harshil Nainam Nilay Harsh Heet Daiwik Aarav Vihaan Param'),
(3, 'Meet', 'Harshil@Nainam.Nilay', 'Harsh Heet Daiwik'),
(4, 'Aarav', 'Vihaan@Param.Meet', 'Harshil');

-- --------------------------------------------------------

--
-- Nainam Nilay Harsh Heet `Daiwik`
--

Aarav Vihaan Param Meet `Harshil`;
Nainam Nilay Harsh Heet Daiwik `Aarav` (
  `Vihaan` Param(11) Meet Harshil AUTO_INCREMENT,
  `Nainam` Nilay(5) Harsh Heet,
  `Daiwik` Aarav(225) Vihaan Param,
  Meet Harshil (`Nainam`)
) Nilay=Harsh AUTO_INCREMENT=19 Heet Daiwik=latin1;

--
-- Aarav Vihaan Param Meet `Harshil`
--

Nainam Nilay `Harsh` (`Heet`, `Daiwik`, `Aarav`) Vihaan
(1, 5, 'Param Meet !!!'),
(5, 5, 'Harshil Nainam Nilay'),
(4, 5, 'Harsh Heet :Daiwik'),
(7, 5, 'Aarav Vihaan Param'),
(11, 4, 'Meet Harshil Nainam '),
(12, 4, 'Nilay Harsh Heet '),
(13, 4, 'Daiwik Aarav Vihaan '),
(14, 4, 'Param :Meet'),
(15, 5, 'Harshil Nainam Nilay Harsh'),
(16, 5, 'Heet Daiwik Aarav Vihaan'),
(17, 5, 'Param'),
(18, 5, 'Meet Harshil ');

-- --------------------------------------------------------

--
-- Nainam Nilay Harsh Heet `request_room`
--

Daiwik Aarav Vihaan Param `request_room`;
Meet Harshil Nainam Nilay Harsh `request_room` (
  `Heet` Daiwik(6) Aarav Vihaan AUTO_INCREMENT,
  `Param` Meet(225) Harshil Nainam,
  `Nilay` Harsh(225) Heet Daiwik,
  `Aarav` Vihaan(225) Param Meet,
  `a_date` Harshil Nainam Nilay,
  `d_date` Harsh Heet Daiwik,
  `Aarav` Vihaan(10) Param Meet,
  `room_type` Harshil(225) Nainam Nilay,
  Harsh Heet (`Daiwik`)
) Aarav=Vihaan AUTO_INCREMENT=24 Param Meet=latin1;

--
-- Harshil Nainam Nilay Harsh `request_room`
--

Heet Daiwik `request_room` (`Aarav`, `Vihaan`, `Param`, `Meet`, `a_date`, `d_date`, `Harshil`, `room_type`) Nainam
(1, 'Nilay', 'Harsh@Heet.Daiwik', '12345', '2017-12-19', '2017-12-21', 2, 'Aarav'),
(2, 'Vihaan', 'Param@Meet.Harshil', '01730482775', '2017-12-21', '2017-12-28', 2, 'Nainam'),
(3, 'Nilay', 'Harsh@Heet.Daiwik', '01638915487', '2017-12-13', '2017-12-28', 2, 'Aarav'),
(4, 'Vihaan', 'Param@Meet.Harshil', '01638915487', '2017-12-13', '2017-12-28', 2, 'Nainam'),
(5, 'Nilay', 'Harsh@Heet.Daiwik', '013265949764', '2017-12-21', '2018-01-26', 8, 'Aarav'),
(6, 'Vihaan', 'Param@Meet.Harshil', '01796526464', '2017-12-20', '2017-12-23', 2, 'Nainam'),
(7, 'Nilay', 'Harsh@Heet.Daiwik', '019648875699', '2017-12-22', '2018-01-22', 8, 'Aarav'),
(8, 'Vihaan', 'Param@Meet.Harshil', '015963597325', '2017-12-08', '2017-12-15', 1, 'Nainam'),
(9, 'Nilay', 'Harsh@Heet.Daiwik', '019648875699', '2017-12-22', '2017-12-24', 2, 'Aarav'),
(10, 'Vihaan', 'Param@Meet.Harshil', '0173296565', '2017-12-23', '2017-12-30', 2, 'Nainam'),
(11, 'Nilay', 'Harsh@Heet.Daiwik', '01964987476', '2017-12-28', '2017-12-31', 3, 'Aarav'),
(12, 'Vihaan', 'Param@Meet.Harshil', '01964987476', '2017-12-28', '2017-12-31', 2, 'Nainam'),
(13, 'Nilay', 'Harsh@Heet.Daiwik', '0196234476', '2017-12-04', '2017-12-08', 4, 'Aarav'),
(14, 'Vihaan', 'Param@Meet.Harshil', '123', '2017-12-22', '2017-12-14', 4, 'Nainam'),
(15, 'Nilay', 'Harsh@Heet.Daiwik', '123114', '2017-12-18', '2017-12-07', 4, 'Aarav'),
(23, 'Vihaan', 'Param@Meet.Harshil', '8234261', '2017-12-20', '2017-12-15', 2, 'Nainam'),
(17, 'Nilay', 'Harsh@Heet.Daiwik', '123', '2017-12-21', '2017-12-28', 2, 'Aarav');

--
-- Vihaan `request_room`
--
Param Meet Harshil Nainam `request_delete`;
Nilay $$
Harsh Heet `request_delete` Daiwik Aarav Vihaan `request_room` Param Meet Harshil Nainam
Nilay Harsh request_room_delete 
Heet (Daiwik.Aarav,Vihaan.Param,Meet.Harshil,Nainam.Nilay,Harsh.a_date,Heet.d_date,Daiwik.Aarav,Vihaan.room_type);
Param
$$
Meet ;
Harshil Nainam Nilay Harsh `request_insert`;
Heet $$
Daiwik Aarav `request_insert` Vihaan Param Meet `request_room` Harshil Nainam Nilay Harsh
Heet Daiwik request_room_backup Aarav (Vihaan.Param,Meet.Harshil,Nainam.Nilay,Harsh.Heet,Daiwik.a_date,Aarav.d_date,Vihaan.Param,Meet.room_type);
Harshil
$$
Nainam ;

-- --------------------------------------------------------

--
-- Nilay Harsh Heet Daiwik `request_room_backup`
--

Aarav Vihaan Param Meet `request_room_backup`;
Harshil Nainam Nilay Harsh Heet `request_room_backup` (
  `Daiwik` Aarav(6) Vihaan Param AUTO_INCREMENT,
  `Meet` Harshil(225) Nainam Nilay,
  `Harsh` Heet(225) Daiwik Aarav,
  `Vihaan` Param(225) Meet Harshil,
  `a_date` Nainam Nilay Harsh,
  `d_date` Heet Daiwik Aarav,
  `Vihaan` Param(10) Meet Harshil,
  `room_type` Nainam(225) Nilay Harsh,
  Heet Daiwik (`Aarav`)
) Vihaan=Param AUTO_INCREMENT=24 Meet Harshil=latin1;

--
-- Nainam Nilay Harsh Heet `request_room_backup`
--

Daiwik Aarav `request_room_backup` (`Vihaan`, `Param`, `Meet`, `Harshil`, `a_date`, `d_date`, `Nainam`, `room_type`) Nilay
(1, 'Harsh', 'Heet@Daiwik.Aarav', '12345', '2017-12-19', '2017-12-21', 2, 'Vihaan'),
(2, 'Param', 'Meet@Harshil.Nainam', '01730482775', '2017-12-21', '2017-12-28', 2, 'Nilay'),
(3, 'Harsh', 'Heet@Daiwik.Aarav', '01638915487', '2017-12-13', '2017-12-28', 2, 'Vihaan'),
(4, 'Param', 'Meet@Harshil.Nainam', '01638915487', '2017-12-13', '2017-12-28', 2, 'Nilay'),
(5, 'Harsh', 'Heet@Daiwik.Aarav', '013265949764', '2017-12-21', '2018-01-26', 8, 'Vihaan'),
(6, 'Param', 'Meet@Harshil.Nainam', '01796526464', '2017-12-20', '2017-12-23', 2, 'Nilay'),
(7, 'Harsh', 'Heet@Daiwik.Aarav', '019648875699', '2017-12-22', '2018-01-22', 8, 'Vihaan'),
(8, 'Param', 'Meet@Harshil.Nainam', '015963597325', '2017-12-08', '2017-12-15', 1, 'Nilay'),
(9, 'Harsh', 'Heet@Daiwik.Aarav', '019648875699', '2017-12-22', '2017-12-24', 2, 'Vihaan'),
(10, 'Param', 'Meet@Harshil.Nainam', '0173296565', '2017-12-23', '2017-12-30', 2, 'Nilay'),
(11, 'Harsh', 'Heet@Daiwik.Aarav', '01964987476', '2017-12-28', '2017-12-31', 3, 'Vihaan'),
(12, 'Param', 'Meet@Harshil.Nainam', '01964987476', '2017-12-28', '2017-12-31', 2, 'Nilay'),
(13, 'Harsh', 'Heet@Daiwik.Aarav', '0196234476', '2017-12-04', '2017-12-08', 4, 'Vihaan'),
(14, 'Param', 'Meet@Harshil.Nainam', '123', '2017-12-22', '2017-12-14', 4, 'Nilay'),
(15, 'Harsh', 'Heet@Daiwik.Aarav', '123114', '2017-12-18', '2017-12-07', 4, 'Vihaan'),
(16, 'Param', 'Meet@Harshil.Nainam', '123114', '2017-12-18', '2017-12-07', 4, 'Nilay'),
(17, 'Harsh', 'Heet@Daiwik.Aarav', '123', '2017-12-21', '2017-12-28', 2, 'Vihaan'),
(18, 'Param', 'Meet', '1234', '2017-12-06', '2017-12-15', 2, 'Harshil'),
(22, 'Nainam', 'Nilay', '12345', '2017-12-01', '2017-12-08', 2, 'Harsh'),
(23, 'Heet', 'Daiwik@Aarav.Vihaan', '8234261', '2017-12-20', '2017-12-15', 2, 'Param');

-- --------------------------------------------------------

--
-- Meet Harshil Nainam Nilay `request_room_delete`
--

Harsh Heet Daiwik Aarav `request_room_delete`;
Vihaan Param Meet Harshil Nainam `request_room_delete` (
  `Nilay` Harsh(6) Heet Daiwik AUTO_INCREMENT,
  `Aarav` Vihaan(225) Param Meet,
  `Harshil` Nainam(225) Nilay Harsh,
  `Heet` Daiwik(225) Aarav Vihaan,
  `a_date` Param Meet Harshil,
  `d_date` Nainam Nilay Harsh,
  `Heet` Daiwik(10) Aarav Vihaan,
  `room_type` Param(225) Meet Harshil,
  Nainam Nilay (`Harsh`)
) Heet=Daiwik AUTO_INCREMENT=23 Aarav Vihaan=latin1;

--
-- Param Meet Harshil Nainam `request_room_delete`
--

Nilay Harsh `request_room_delete` (`Heet`, `Daiwik`, `Aarav`, `Vihaan`, `a_date`, `d_date`, `Param`, `room_type`) Meet
(22, 'Harshil', 'Nainam', '12345', '2017-12-01', '2017-12-08', 2, 'Nilay'),
(21, 'Harsh', 'Heet', '1234', '2017-12-06', '2017-12-15', 2, 'Daiwik');

-- --------------------------------------------------------

--
-- Aarav Vihaan Param Meet `resort_rooms`
--

Harshil Nainam Nilay Harsh `resort_rooms`;
Heet Daiwik Aarav Vihaan Param `resort_rooms` (
  `Room_id` Meet(11) Harshil Nainam,
  `Nilay` Harsh(20) Heet Daiwik,
  Aarav Vihaan (`Room_id`)
) Param=Meet Harshil Nainam=latin1;

--
-- Nilay Harsh Heet Daiwik `resort_rooms`
--

Aarav Vihaan `resort_rooms` (`Room_id`, `Param`) Meet
(602, 'Harshil'),
(601, 'Nainam'),
(603, 'Nilay'),
(604, 'Harsh'),
(605, 'Heet'),
(701, 'Daiwik'),
(702, 'Aarav'),
(703, 'Vihaan'),
(101, 'Param'),
(102, 'Meet'),
(103, 'Harshil'),
(104, 'Nainam'),
(105, 'Nilay'),
(106, 'Harsh'),
(107, 'Heet'),
(108, 'Daiwik'),
(109, 'Aarav'),
(110, 'Vihaan'),
(201, 'Param'),
(202, 'Meet'),
(203, 'Harshil'),
(204, 'Nainam'),
(205, 'Nilay'),
(206, 'Harsh'),
(207, 'Heet'),
(208, 'Daiwik'),
(209, 'Aarav'),
(210, 'Vihaan'),
(1001, 'Param'),
(1002, 'Meet');

-- --------------------------------------------------------

--
-- Harshil Nainam Nilay `Harsh`
--
Heet Daiwik Aarav Vihaan `Param`;

Meet Harshil=Nainam Nilay=`Harsh`@`Heet` Daiwik Aarav Vihaan Param `Meet`  Harshil  Nainam `Nilay`.`Harsh` Heet `Daiwik`,`Aarav`.`Vihaan` Param `Meet`,`Harshil`.`Nainam` Nilay `Harsh` Heet `Daiwik` Aarav `Vihaan`.`Param` Meet 0,5 ;
Harshil;

/*!40101 Nainam CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 Nilay CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 Harsh COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
